str = "PLease contact info@sololearn.com"
man = "please help manishaagarwal838@gmail.com"
