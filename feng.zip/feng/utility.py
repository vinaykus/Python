import calendar
import datetime
import pandas as pd



def getStatus(x):
    """ status information """
    status = ""
    if x['Completed on'] == "NONE":
        if x['Due date'] != "NONE":
            d3 = pd.to_datetime(x['Due date']) - datetime.datetime.now()
            if d3.days < 0:
                status = "OVERDUE"
            else:
                status = "OPEN"
        elif x['Due date'] == "NONE":
            status = "OPEN"
    elif x['Completed on'] != "NONE":
        if x['Due date'] != "NONE":
            d3 = pd.to_datetime(x['Completed on']) - pd.to_datetime(x['Due date'])
            if d3.days > 0:
                status = "OVERDUE_CLOSED"
            else:
                status = "CLOSED"
        elif x['Due date'] == "NONE":
            status = "CLOSED"
    return status

def setMonthYear(row):
    """ month-year"""
    dateArr = []
    if row['Start date'] != "NONE":
        d3 = pd.to_datetime(row['Start date'])
        dateArr.append(str(calendar.month_abbr[d3.month]))
        dateArr.append(str(d3.year))
    return "-".join(dateArr)


def setYear(row):
    """year"""
    if row['Start date'] != "NONE":
        d5 = pd.to_datetime(row['Start date'])
        return d5.year


def setMonth(x):
    """month"""
    if x['Start date'] != "NONE":
        d1 = pd.to_datetime(x['Start date'])
        return d1.month


def setWorkspace(row):
    """workspace data"""
    workspace = ""
    if isinstance(row['Workspaces'], str):
        if 'operational' in row['Workspaces']:
            workspace = "Operational"
        elif 'projects' in row['Workspaces']:
            workspace = "Project"
        else:
            workspace = "None"
    else:
        workspace = "None"
    return workspace


def dfDateFilter(start_date,end_date, df):
    if start_date is not None and end_date is not None:
        df1 = df[(pd.to_datetime(df['Start date'], dayfirst=True, errors='ignore') > start_date)&(pd.to_datetime(df['Start date'], dayfirst=True, errors='ignore') < end_date)]
    elif start_date is not None and end_date is None:
        df1 = df[(pd.to_datetime(df['Start date'], dayfirst=True, errors='ignore') > start_date)]
    elif start_date is None and end_date is not None:
        df1 = df[(pd.to_datetime(df['Start date'], dayfirst=True, errors='ignore') < end_date)]
    else:
        df1 = df
    return df1

def groupDf(df):
    groupedByTagsWs = df
    groupedByTagsWs['startDateWeek'] = pd.DatetimeIndex(groupedByTagsWs['Start date']).week
    groupedByTagsWs1 = pd.DataFrame({'count' : groupedByTagsWs.groupby(['Tags','startDateWeek']).size()}).reset_index()
    groupedByTagsWs1 = groupedByTagsWs1.pivot(index='startDateWeek',columns='Tags',values='count')
    return groupedByTagsWs1