import dash
import appLayout
import appRender
import appData
from dash.dependencies import Input, Output
import plotly.graph_objs as go

@appLayout.app.callback(
dash.dependencies.Output('my-graph', 'figure'),
[dash.dependencies.Input('tags', 'value')],
)
def update_graph(tags):
    tagstatus = appData.df.groupby([ 'Tags', 'status'])['Id'].count().reset_index().rename(
    columns={'Id': 'count'}).sort_values('count')
    trace1 = go.Bar(
    x = tagstatus[(tagstatus['Tags']== tags ) ]['status'].tolist(),
    y = tagstatus[(tagstatus['Tags']==tags) ]['count'].tolist()
    )
    return {
        'data': [trace1],
        'layout': {
            'title': 'Rolls-Royce Aircraft Engine Model Types',
            'colorway': ["#10069f"],
            'hovermode': "closest",
            'xaxis': {'title': "Counts of Aircrafts"},
            'yaxis': {'title': "Aircraft Engine Model"},
        }
    }


if __name__ == '__main__':
    appLayout.app.run_server(host='127.0.0.1',  debug=True)