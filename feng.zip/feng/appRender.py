import dash_html_components as html
import dash
import plotly.graph_objs as go
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import appData
import appCharts
from datetime import datetime as dt
import pandas as pd
import appLayout


def overAllOverview():
    
    return html.Div([html.Div([
        html.Div([
            html.H2('Overview')
        ], className='titleHr aav aaj', id='topTitle')
    ], className='col-sm-6 col-md-12 col-lg-12', id="topMost"), 
    dbc.Row(
        [
            dbc.Col(dbc.Card([
    dbc.CardHeader("Total Task"),
    dbc.CardBody(
        [
            html.H2(appData.df['Id'].count(), className="card-title"),
           
        ]
    ),
], color="primary")),
            dbc.Col(dbc.Card([
    dbc.CardHeader("Completed"),
    dbc.CardBody(
        [
            html.H2(appData.df['Id'].count(), className="card-title"),
           
        ]
    ),
], color="light", outline=True)),
            dbc.Col(dbc.Card([
    dbc.CardHeader("Overdue"),
    dbc.CardBody(
        [
            html.H5("Card title", className="card-title"),
            html.P(
                "This is some card content that we'll reuse",
                className="card-text",
            ),
        ]
    ),
], color="light")),
            dbc.Col(dbc.Card([
    dbc.CardHeader("Open"),
    dbc.CardBody(
        [
            html.H5("Card title", className="card-title"),
            html.P(
                "This is some card content that we'll reuse",
                className="card-text",
            ),
        ]
    ),
], color="light")),
        ] ),
        html.Hr(),
        dbc.Row(dbc.Col(
             dcc.Graph(id="my-graph",
                                      

                                      style={'heigth': 30, 'width': 700, 'display': 'inline-block', 'margin': 0,
                                             'marginBottom': 0, 'marginTop': 0},
                                      ),


        )),
        html.Hr(),
        dbc.Row([
            dbc.Col(html.Div(appCharts.generateBar(appData.groupTags, hovermode='closest', barmode='stack',
                                                   title='Task count based on status', xaxisTitle='',orientation='h',
                                                   yaxisTitle='# no of Tasks', chartId='chart', legendOrientation="v",
                                                   legendYPos=1, legendXPos=0.02))),

        ])])


