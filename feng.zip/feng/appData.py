import pandas as pd
from utility import getStatus, setMonthYear, setMonth, setYear, setWorkspace
from datetime import datetime as dt
import math

df = pd.read_csv('export.csv',sep=',',encoding ='latin1', parse_dates=['Completed on', 'Due date', 'Start date'])
df =df[['Id','Assigned to', 'Completed by','Completed on', 'Due date',  'Name', 'Start date', 'Tags', 'Workspaces']]
for col in df.select_dtypes(include=['datetime']):
    df[col] = df[col].dt.strftime('%d-%m-%Y')

df['CompletedWeek'] = pd.DatetimeIndex(df['Completed on']).week
df = df.fillna('NONE')
for col in df.select_dtypes(include=['object']):
    df[col] = df[col].apply(lambda x : "NONE" if x=="NaT" else x)

df['status'] = df.apply(getStatus, axis=1)
df['assignedStatus'] = df.apply(lambda x: "NOT ASSIGNED" if x['Assigned to'] == "NONE" else "ASSIGNED", axis=1)
df['month_year'] = df.apply(setMonthYear, axis=1)
df['month'] = df.apply(setMonth, axis=1)
df['year'] = df.apply(setYear, axis=1)
df['workspaceGroup'] = df.apply(setWorkspace, axis=1)
df = df.sort_values(['month','year'])


noStartDate = df[df['Start date'] == 'NONE']
noStartDateCompleted = noStartDate[(noStartDate['status']=='CLOSED')]
noStartDateOpen = noStartDate[(noStartDate['status']=='OPEN')]
withStartDate = df[df['Start date'] != 'NONE']
projectedTasks = withStartDate[pd.to_datetime(withStartDate['Start date'], errors='ignore') > dt.now()]
projectedTasksWoBl = projectedTasks[~projectedTasks['Tags'].str.contains('status')]
overdueYetToComplete = withStartDate[withStartDate['status']=='OVERDUE_OPEN']
overdueYetToCompleteWoBl = overdueYetToComplete[~overdueYetToComplete['Tags'].str.contains('status')]
overdueComplete = withStartDate[withStartDate['status']=='OVERDUE_CLOSED']
overdueCompleteWoBl = overdueComplete[~overdueComplete['Tags'].str.contains('status')]
openTasks = withStartDate[withStartDate['status'].str.contains('OPEN')]
openTasks = openTasks[pd.to_datetime(openTasks['Start date'], errors='ignore') < dt.now()]
openTasksWoBl = openTasks[~openTasks['Tags'].str.contains('status')]
openTasksWoBl = openTasksWoBl[~openTasksWoBl['Tags'].str.contains('Bug')]
closeTasks = withStartDate[withStartDate['status'].str.contains('CLOSED')]
closeTasks = closeTasks[pd.to_datetime(closeTasks['Start date'], errors='ignore') < dt.now()]
closeTasksWoBl = closeTasks[~closeTasks['Tags'].str.contains('status')]
closeTasksWoBl = closeTasksWoBl[~closeTasksWoBl['Tags'].str.contains('Bug')]


completeOpenList = pd.concat([projectedTasksWoBl,overdueYetToCompleteWoBl,openTasksWoBl]).drop_duplicates().reset_index(drop=True)

groupTags = pd.DataFrame({'count' : df.groupby( [ "Tags", "status"] ).size()}).reset_index()
tagNames = (groupTags['Tags'].unique().tolist())
#print(groupTags)

groupTags = groupTags.pivot(index='Tags',columns='status',values='count')
groupTags = groupTags.fillna(0)






