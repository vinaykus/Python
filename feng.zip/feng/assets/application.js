/* off-canvas sidebar toggle */
$('[data-toggle=offcanvas]').click(function(e) {
    e.preventDefault()
    $('.row-offcanvas').toggleClass('active');
    $('.collapse').toggleClass('in').toggleClass('hidden-xs').toggleClass('visible-xs');
});
