import plotly.graph_objs as go
import dash_html_components as html
import dash_core_components as dcc
import appData



def generateBar(df, hovermode='closest', barmode='bar', title='', xaxisTitle='',orientation='', yaxisTitle='', chartId='chart',
                xaxisTickangle=90, colorcount="", colortype="qual", colorbar="Paired", colorenhance=False,
                callback=False, legendOrientation="h", legendXPos="0", legendYPos="-0.15"):
    list_x = df.index.values
    data = []
    i = 0
    if colorcount != "" and colorenhance:
        colorList = ['rgb(23, 190, 207)', 'rgb(0, 140, 149)', 'rgb(255, 127, 14)', 'rgb(214, 39, 40)',
                     'rgb(148, 103, 189)', 'rgb(140, 86, 75)', 'rgb(127, 127, 127)', 'rgb(188, 189, 34)',
                     'rgb(44, 160, 44)', 'rgb(128,0,38)',
                     'rgb(31, 119, 180)', 'rgb(51, 99, 142)', 'rgb(247, 204, 169)', 'rgb(150, 192, 66)',
                     'rgb(192, 66, 87)', 'rgb(226, 38, 79)', 'rgb(28, 48, 33)', 'rgb(76, 100, 143)', 'rgb(86, 106, 64)',
                     'rgb(140, 75, 129)']
        # print(plotly.colors.PLOTLY_SCALES)
    elif colorcount != "" and colorenhance == False:
        colorList = ['rgb(23, 190, 207)', 'rgb(0, 140, 149)', 'rgb(255, 127, 14)', 'rgb(214, 39, 40)',
                     'rgb(148, 103, 189)', 'rgb(140, 86, 75)', 'rgb(127, 127, 127)', 'rgb(188, 189, 34)',
                     'rgb(44, 160, 44)', 'rgb(128,0,38)',
                     'rgb(31, 119, 180)', 'rgb(51, 99, 142)', 'rgb(247, 204, 169)', 'rgb(150, 192, 66)',
                     'rgb(192, 66, 87)', 'rgb(226, 38, 79)', 'rgb(28, 48, 33)', 'rgb(76, 100, 143)', 'rgb(86, 106, 64)',
                     'rgb(140, 75, 129)']
    for col in df:
        if colorcount == "":
            data.append(go.Bar(y=list_x, x=df[col].tolist(), name=col, orientation='h'))
        else:
            data.append(go.Bar(y=list_x, x=df[col].tolist(), marker=go.bar.Marker(color=colorList[i]), name=col,orientation='h'))
        i += 1
    return dcc.Graph(
        id='example-graph',
        config={
            "displaylogo": False,
            'modeBarButtonsToRemove': ['pan2d', 'lasso2d']
        },
        figure={
            'data': data,
            'layout': dict(
                hovermode=hovermode,
                barmode=barmode,
                title=title,

                xaxis=dict(
                    title=xaxisTitle,
                    titlefont=dict(
                        family='Arial, sans-serif',
                        size=14,
                        color='grey'
                    ),
                    showticklabels=True,
                    tickangle=xaxisTickangle,
                    tickfont=dict(
                        family='Arial, sans-serif',
                        size=12,
                        color='grey'
                    ),
                    gridwidth=2,
                ),
                yaxis=dict(
                    title=yaxisTitle,
                    titlefont=dict(
                        family='Arial, sans-serif',
                        size=14,
                        color='grey'
                    ),
                    showticklabels=True,
                    tickfont=dict(
                        family='Arial, sans-serif',
                        size=12,
                        color='grey'
                    ),
                    gridwidth=2,
                ),
                margin=dict(l=50, r=50, t=50, b=50),
                legend=dict(
                    orientation=legendOrientation,
                    x=legendXPos,
                    y=legendYPos,
                    tracegroupgap=5,
                    bgcolor='rgba(151, 183, 52, 0.2)',
                    bordercolor='rgb(255, 255, 255, 0)'
                )
            )

        }
    )


def generateScatter(df, hovermode='closest', title='', xaxisTitle='', yaxisTitle='', chartId='chart', mode='lines',
                    xaxisTickangle=90, ):
    df = appData.monthlyCountData
    x = df.index.values
    for col in df:
        y = df[col].tolist()
    return html.Div([
        dcc.Graph(
            id='life-exp-vs-gdp',
            config={
                "displaylogo": False,
                'modeBarButtonsToRemove': ['pan2d', 'lasso2d']
            },
            figure={
                'data': [
                    go.Scatter(
                        x=x,
                        y=y,
                        mode=mode,
                        name=col
                    )
                ],
                'layout': go.Layout(
                    xaxis=dict(
                        title=xaxisTitle,
                        titlefont=dict(
                            family='Arial, sans-serif',
                            size=14,
                            color='grey'
                        ),
                        showticklabels=True,
                        tickangle=xaxisTickangle,
                        tickfont=dict(
                            family='Arial, sans-serif',
                            size=12,
                            color='grey'
                        ),
                        gridwidth=2,

                    ),
                    yaxis=dict(
                        title=yaxisTitle,
                        titlefont=dict(
                            family='Arial, sans-serif',
                            size=14,
                            color='grey'
                        ),
                        showticklabels=True,
                        # tickangle=45,
                        tickfont=dict(
                            family='Arial, sans-serif',
                            size=12,
                            color='grey'
                        ),
                        gridwidth=2,
                    ),
                    legend=dict(
                        x=0,
                        y=1.0,
                        bgcolor='rgba(151, 183, 52, 0.2)',
                        bordercolor='rgb(255, 255, 255, 0)'
                    ),
                    hovermode=hovermode,
                    title=title,
                )
            }
        )

    ])


def generatePie(df, hovermode='closest', title='', annotationText='', chartId='pieChart', hole=0.5,
                textPosition='outside', textInfo='value+percent', pullValue='0', hoverinfo='all', labelColName='',
                labelColValues=''):
    if labelColName == '' or labelColValues == '':
        print('Column name & value are required!')
    else:
        values = df['colValue']
        labels = df['realColName']
        type = "pie"
        textposition = textPosition
        data = [{"values": values, "labels": labels, "type": type, "textposition": textPosition, "hole": hole,
                 "textinfo": textInfo}]
        layout = go.Layout(
            title=title,
            annotations=[dict(
                font=dict(
                    size=13),
                text=annotationText,
                showarrow=False,

            )]
        )
        return dcc.Graph(id=chartId, figure={'data': data, 'layout': layout},config={
                                 "displaylogo": False,
                                 'modeBarButtonsToRemove': ['pan2d', 'lasso2d']
                             },)


