from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
import dash
import dash_html_components as html
import dash_core_components as dcc
import os
import base64
import appData
import appRender
import dash_bootstrap_components as dbc
from datetime import datetime as dt

SERVER_PATH = os.path.dirname(os.path.abspath(__file__))
app = dash.Dash(
    __name__,
    assets_folder=os.path.join(SERVER_PATH, "assets"),
    suppress_callback_exceptions=True,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    meta_tags=[
        {"name": "viewport", "content": "width=device-width, initial-scale=1"}
    ],
)

server = app.server

path = os.path.join(SERVER_PATH, "assets", "RR.png")
encoded_image = base64.b64encode(open(path, 'rb').read())
image_src = 'data:image/png;base64,{}'.format(encoded_image.decode())

sidebar_header = dbc.Row(
    [

        html.Div(html.Img(src=image_src, alt='Rolls-Royce'), style={'float': 'right'}, id="navlogo"),

        dbc.Col(
            [
                html.Button(
                    # use the Bootstrap navbar-toggler classes to style
                    html.Span(className="navbar-dark navbar-toggler-icon"),
                    className="navbar-toggler",
                    # the navbar-toggler classes don't set color
                    style={
                        "color": "#FFFFFF",
                        "border-color": "rgba(0,0,0,.1)",
                    },
                    id="navbar-toggle",
                ),
                html.Button(
                    # use the Bootstrap navbar-toggler classes to style
                    html.Span(className=" navbar-dark navbar-toggler-icon"),
                    className="navbar-toggler",
                    # the navbar-toggler classes don't set color
                    style={
                        "color": "#FFFFFF",
                        "border-color": "rgba(0,0,0,.1)",
                    },
                    id="sidebar-toggle",
                ),

            ],
            # the column containing the toggle will be only as wide as the
            # toggle, resulting in the toggle being right aligned
            width="auto",
            # vertically align the toggle in the center
            align="center",
        ),
    ]
)

sidebar = html.Div(
    [
        sidebar_header,
        # we wrap the horizontal rule and short blurb in a div that can be
        # hidden on a small screen
        html.Div(
            [
                html.Hr(),
                html.B(
                    "Feng Dashboard",
                    className="lead",
                ),
                html.Hr(),
            ],
            id="blurb",
        ),
        # use the Collapse component to animate hiding / revealing links
        dbc.Collapse(
            dbc.Nav(
                [
                     
                     
                    dbc.Label("Task by Group"),
                  dcc.Dropdown(id ='tags', options=[{'label': i, 'value': i} for i in appData.df['Tags'].unique()],
                                             value=' ',
                    ),
                    dbc.Label("Task by status"),
          dcc.Dropdown(options=[{'label': i, 'value': i} for i in appData.df['status'].unique()],
                                             value='OPEN',
                    )  ,
                    dbc.Label("Assigned To"),
             dcc.Dropdown(options=[{'label': i, 'value': i} for i in appData.df['Assigned to'].unique()],
                                             value='Harsha',
                    )  ,
                    dbc.Label("Task by workspace"),
                    dcc.Dropdown(options=[{'label': i, 'value': i} for i in appData.df['Workspaces'].unique()],
                                             value='weekly follow up',
                    ) ,
                    html.Hr(),
                        dbc.Tooltip(
                        'Edit Section', target='page-1-link', placement='right'),
                    dbc.NavLink(" General Overview", href="/page-1", id="page-1-link", className="fa fa-table collapse in hidden-xs"),
                       
                ],
                vertical=True,
                pills=True,
            ),
            id="collapse",
        ),
    ],
    id="sidebar",
)

content = html.Div(id="page-content")
##############################################################
#                                                            #
#                   L  A  Y  O  U  T                         #
#                                                            #
##############################################################
app.title = "Feng Reporting"
app.layout = html.Div([dcc.Location(id="url"), sidebar, content])


# this callback uses the current pathname to set the active state of the
# corresponding nav link to true, allowing users to tell see page they are on
@app.callback(
    [Output(f"page-{i}-link", "active") for i in range(1, 5)],
    [Input("url", "pathname")],
)
def toggle_active_links(pathname):
    if pathname == "/":
        # Treat page 1 as the homepage / index
        return True, False, False, False
    return [pathname == f"/page-{i}" for i in range(1, 5)]


@app.callback(Output("page-content", "children"), [Input("url", "pathname")])
def render_page_content(pathname):
    if pathname in ["/", "/page-1"]:
        return appRender.overAllOverview()
   
    
    # If the user tries to reach a different page, return a 404 message
    return dbc.Jumbotron(
        [
            html.H1("404: Not found", className="text-danger"),
            html.Hr(),
            html.P(f"The pathname {pathname} was not recognised..."),
        ]
    )


@app.callback(
    Output("sidebar", "className"),
    [Input("sidebar-toggle", "n_clicks")],
    [State("sidebar", "className")],
)
def toggle_classname(n, classname):
    if n and classname == "":
        return "collapsed"
    return ""


@app.callback(
    Output("collapse", "is_open"),
    [Input("navbar-toggle", "n_clicks")],
    [State("collapse", "is_open")],
)
def toggle_collapse(n, is_open):
    if n:
        return not is_open
    return is_open


