#Given two lines on a Cartesian plane, determine whether the two lines would inter- sect.

#no matter this is a same line or different lines are parallel
# they slope must be the same, so compare the slope is enough in this case.
        
    