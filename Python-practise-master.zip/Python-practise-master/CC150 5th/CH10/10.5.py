If you were designing a web crawler, how would you avoid getting into infinite loops?

#ans
hash table (unique one) + BFS
