# You have an array with all the numbers from 1 to N, where N is at most 32,000. 
# The array may have duplicate entries and you do not know what N is. With only 4KB of memory available, 
# how would you print all duplicate elements in the array?
# 4KB = 2^(12) * 2^(3) = 2 ^ (15)
# 1 bit represent one int.
# 1), case1, flip 0 to 1
# 2), case2, if bit is "1", then print the int

#The ans is confused, need to discuss later

