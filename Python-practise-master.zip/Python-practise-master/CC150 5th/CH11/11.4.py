#If you have a 2 GB file with one string per line,
#which sorting algorithm would you use to sort the file and why?


Step1, divide files into 20 small files and 1 GB for each file and bring them seperated into the memory
Step2, using radix sort for each small files
Step3, merge 1 by 1 for all the files











