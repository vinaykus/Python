What are the different types of Joins? Please explain how they diff and why certain types are 
better in certain situations.

Natural join --> exactly same term
Outer join (LEFT JOIN, RIGHT JOIN, FULL OUTER JOIN) --> make up by the NULL arguments




