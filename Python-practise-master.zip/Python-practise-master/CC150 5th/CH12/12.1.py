#include <stdio.h>

// To execute C, please define "int main()"

int main() {
  unsigned int i;
  for(i=100;i>0;--i){
    printf("%d\n", i);
  }
  return 0;
}








